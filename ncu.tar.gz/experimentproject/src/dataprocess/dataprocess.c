static BOOL StdEquip_ACU_ProcessModbusSignals(IN SITE_INFO *pSite)
{
#define SYS_EQUIPID 1
#define OB_BATTFUSE_EQUIPID    159
#define OB_DCFUSE_EQUIPID	177
#define	SMDUH1_EQUIPID	1702
#define	EIB1_EQUIPID	197
#define MAX_SIG_NUM	     32
	
	enum MODBUS_SPECIAL_SIGNAL
	{
		SIG_RECT_OAMA_SUM =33,
		SIG_OBBATTFUSE1_2_3_SUM =34,
		SIG_OBDCFUSE1_2_3_4_SUM =35,
		SIG_SMDUH15_7_9_11_SUM =36,
		SIG_EIB1_2_3_4_BADBLOCK_SUM =37,
		SIG_SMDUH1LOADPWR_SUM =38,
	};
	enum MODBUSVALUE_GROUPTYPE
	{
		LOAD_ENERGY	 =0,
		OB_BATTFUSE	 =1,
		OB_DCFUSE		=2,
		SMDUH1_LOAD =3,
		EIB1_BADBLOCK =4,
		END_GROUPTYPE,
	};
	enum MODBUS_VALUE_TYPE
	{
		TYPE_ENUM_VALUE	 =0,
		TYPE_FLOAT_VALUE	 =1,
	};
	struct	tagMODBUS_SPECIAL_PRO_REG
	{
		int		iIndex;
		int		iEquipId;
		int		iSigType;
		int		iSigId;
		int		iValueType;
		int		iGroupType

	};
	typedef struct tagMODBUS_SPECIAL_PRO_REG   MODBUS_SPECIAL_PRO_REG;
	struct	tagMODBUS_VALUE
	{
		float	fValue;
		int		iEnumValue;
	};
	typedef struct   tagMODBUS_VALUE	 MODBUS_VALUE;
	static MODBUS_SPECIAL_PRO_REG s_aModbusSig[] =
	{
		{0,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	214,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 1 Energy
		{1,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	215,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 2 Energy
		{2,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	216,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 3 Energy
		{3,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	217,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 4 Energy
		{4,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	218,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 5 Energy
		{5,	SMDUH1_EQUIPID,SIG_TYPE_SAMPLING,	219,TYPE_FLOAT_VALUE,LOAD_ENERGY},	//SMDUH1 LOAD 6 Energy

		{6,	OB_BATTFUSE_EQUIPID,SIG_TYPE_ALARM,1,TYPE_ENUM_VALUE,OB_BATTFUSE},	//ODBC  BATT FUSE 1 Alarm
		{7,	OB_BATTFUSE_EQUIPID,SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,OB_BATTFUSE},	//ODBC  BATT FUSE 2 Alarm
		{8,	OB_BATTFUSE_EQUIPID,	SIG_TYPE_ALARM,3,TYPE_ENUM_VALUE,OB_BATTFUSE},	//ODBC  BATT FUSE 3 Alarm	
		
		{9,	OB_DCFUSE_EQUIPID,SIG_TYPE_ALARM,1,TYPE_ENUM_VALUE,OB_DCFUSE},	//OB_DCFUSE 1 Alarm
		{10,	OB_DCFUSE_EQUIPID,SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,OB_DCFUSE},	//OB_DCFUSE 2 Alarm
		{11,	OB_DCFUSE_EQUIPID,SIG_TYPE_ALARM,3,TYPE_ENUM_VALUE,OB_DCFUSE},	//OB_DCFUSE 3 Alarm
		{12,	OB_DCFUSE_EQUIPID,SIG_TYPE_ALARM,4,TYPE_ENUM_VALUE,OB_DCFUSE},	//OB_DCFUSE 4 Alarm

		{13,	SMDUH1_EQUIPID,SIG_TYPE_ALARM,5,TYPE_ENUM_VALUE,SMDUH1_LOAD},	//SMDUH1 Load 5 Alarm
		{14,	SMDUH1_EQUIPID,SIG_TYPE_ALARM,7,TYPE_ENUM_VALUE,SMDUH1_LOAD},	//SMDUH1 Load 7 Alarm
		{15,	SMDUH1_EQUIPID,SIG_TYPE_ALARM,9,TYPE_ENUM_VALUE,SMDUH1_LOAD},	//SMDUH1 Load 9 Alarm
		{16,	SMDUH1_EQUIPID,SIG_TYPE_ALARM,11,TYPE_ENUM_VALUE,SMDUH1_LOAD},//SMDUH1 Load 11 Alarm

		{17,	EIB1_EQUIPID,     SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,EIB1_BADBLOCK},	//EIB1 Bad Block Alarm
		{18,	EIB1_EQUIPID+1,SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,EIB1_BADBLOCK},	//EIB2 Bad Block Alarm
		{19,	EIB1_EQUIPID+2,SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,EIB1_BADBLOCK},	//EIB3 Bad Block Alarm
		{20,	EIB1_EQUIPID+3,SIG_TYPE_ALARM,2,TYPE_ENUM_VALUE,EIB1_BADBLOCK},	//EIB4 Bad Block Alarm

		{MAX_SIG_NUM,	0,0,0,0,END_GROUPTYPE	},
	};



	int n=0,i=0,j,iTimeOut= 0,iError,iBufLen;
	static BOOL			bInited = FALSE;
	static int iCount=0;
	static EQUIP_INFO	*pRectEquip = NULL;
	static SIG_BASIC_VALUE *pSigtmp[MAX_SIG_NUM]={NULL};
	static SIG_BASIC_VALUE * pSigValue =NULL;
	static MODBUS_VALUE Value[MAX_SIG_NUM];
	VAR_VALUE  SigValue_Sum[END_GROUPTYPE];
	VAR_VALUE  SigValue_Rect;

	EQUIP_INFO	*pEquip = NULL;
	//1. init one time
	memset(Value,0,sizeof(MODBUS_VALUE)*MAX_SIG_NUM);
	memset(SigValue_Sum,0,sizeof(VAR_VALUE)*END_GROUPTYPE);
	if (!bInited)
	{
		i = 0;
		while(s_aModbusSig[i].iIndex != MAX_SIG_NUM)
		{	 
			iError = DxiGetData(VAR_A_SIGNAL_VALUE,
					s_aModbusSig[i].iEquipId,
					DXI_MERGE_SIG_ID( s_aModbusSig[i].iSigType, s_aModbusSig[i].iSigId ),
					&iBufLen,&pSigValue,
					iTimeOut);
			if( iError == ERR_DXI_OK )
			{
				printf("Sig[%d] find\n",i);
				pSigtmp[i] = pSigValue;
			}
			i++;
		}
		/*for(j=0;j<MAX_SIG_NUM;j++)
		{
			Value[j].fValue=0.0;
			Value[j].iEnumValue=0;
		}*/
		bInited = TRUE;
	}
	//Modbus_Test();
	//get value
	for(j=0;j<MAX_SIG_NUM;j++)
	{
		//sig not exist return NULL
		if( NULL !=pSigtmp[j]	)
		{
			//Float value
			if( pSigtmp[j]->ucType== VAR_FLOAT )
			{
				Value[j].fValue= pSigtmp[j]->varValue.fValue;
				printf("sig i [%d]  floatvalue[%f] \n",j,Value[j].fValue);
			}
			else
			{
				Value[j].iEnumValue=pSigtmp[j]->varValue.enumValue;
				printf("sig [%d] enum value[%d] \n",j,Value[j].iEnumValue);
			}
		}
	}
	
	
	
	i=0;
	while(s_aModbusSig[i].iIndex != MAX_SIG_NUM)
	{
		switch(s_aModbusSig[i].iGroupType)
		{
			case LOAD_ENERGY:
				SigValue_Sum[LOAD_ENERGY].fValue += Value[i].fValue;
				break;
			case OB_BATTFUSE:
				SigValue_Sum[OB_BATTFUSE].enumValue  = (Value[i].iEnumValue | SigValue_Sum[OB_BATTFUSE].enumValue  );
				break;
			case OB_DCFUSE:
				SigValue_Sum[OB_DCFUSE].enumValue  = (Value[i].iEnumValue | SigValue_Sum[OB_DCFUSE].enumValue );
				break;
			case SMDUH1_LOAD:
				SigValue_Sum[SMDUH1_LOAD].enumValue = (Value[i].iEnumValue | SigValue_Sum[SMDUH1_LOAD].enumValue);
				break;
			case EIB1_BADBLOCK:
				SigValue_Sum[EIB1_BADBLOCK].enumValue = (Value[i].iEnumValue | SigValue_Sum[EIB1_BADBLOCK].enumValue);
				break;
			default:
				break;
		}
		
		i++;
	}

	//calculate  Rectifiters MA+OA num
	SigValue_Rect.enumValue= Site_GetRectAlarmCnt(pSite);
	printf("Rect  MA OA Alarm [%d ] \n",SigValue_Rect.enumValue);
	Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Rect,DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_RECT_OAMA_SUM));

	//calculate load total energy	
	printf(" load total energy [%f ] \n",SigValue_Sum[LOAD_ENERGY].fValue);
	 Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Sum[LOAD_ENERGY],DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_SMDUH1LOADPWR_SUM));

	//calculate OB_BATTFUSE fuse1 ,2,3 alarm	
	printf("OB_BATTFUSE  Alarm  [%d ] \n",SigValue_Sum[OB_BATTFUSE].enumValue);
	SigValue_Sum[OB_BATTFUSE].enumValue=(SigValue_Sum[OB_BATTFUSE].enumValue>0)?TRUE:FALSE;
	 Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Sum[OB_BATTFUSE],DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_OBBATTFUSE1_2_3_SUM));

	 //calculate OB_DCFUSE fuse1 ,2,3,4 alarm	
	printf("OB_DCFUSE  Alarm  [%d ] \n",SigValue_Sum[OB_DCFUSE].enumValue);
	SigValue_Sum[OB_DCFUSE].enumValue=(SigValue_Sum[OB_DCFUSE].enumValue>0)?TRUE:FALSE;
	 Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Sum[OB_DCFUSE],DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_OBDCFUSE1_2_3_4_SUM));

	  //calculate SMDUH1 5 7 9 11 alarm
	printf("SMDUH1 Load  alarm [%d ] \n",SigValue_Sum[SMDUH1_LOAD].enumValue);
	SigValue_Sum[SMDUH1_LOAD].enumValue=(SigValue_Sum[SMDUH1_LOAD].enumValue>0)?TRUE:FALSE;
	Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Sum[SMDUH1_LOAD],DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_SMDUH15_7_9_11_SUM));

	   //calculate EIB1~4  Bad Block Alarm 	
	printf("EIB Bad Blockalarm  [%d ] \n",SigValue_Sum[EIB1_BADBLOCK].enumValue );
	SigValue_Sum[EIB1_BADBLOCK].enumValue =(SigValue_Sum[EIB1_BADBLOCK].enumValue >0)?TRUE:FALSE;
	Equip_SetSpecialSigByMergedId(SYS_EQUIPID,SigValue_Sum[EIB1_BADBLOCK],DXI_MERGE_SIG_ID(SIG_TYPE_SAMPLING, SIG_EIB1_2_3_4_BADBLOCK_SUM));	
}