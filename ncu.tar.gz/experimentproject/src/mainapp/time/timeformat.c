/*==========================================================================*
 *    Copyright(c) 2017-2027, ECJTU Co., Ltd.
 *                     ALL RIGHTS RESERVED
 *
 *  PRODUCT  : ACU(Advanced Controller Unit)
 *
 *  FILENAME : main.c
 *  CREATOR  : LiangRao (Lemon)         DATE: 2017-12-29 14:55
 *  VERSION  : V1.00
 *  PURPOSE  : ʱ��ӿڣ���ȡ��ͬ��ʽʱ�䣬Linuxtimerʹ�õ�
 *
 *
 *  HISTORY  :
 *
 *==========================================================================*/
#include "public.h"
#include "pub_time.h"
#include "timeformat.h"

/*==========================================================================*
 * FUNCTION : ServiceManager_Start
 * PURPOSE  :Get current time characters .
 * ARGUMENTS:
Input: const  
Ouput:	 psz_TimeArr
 * RETURN   : BOOL : TRUE for OK
 * COMMENTS :format time    stamp to YY-MM-DD-HH--MN-SS
 *            
 * CREATOR  : Raoliang         DATE: 2018-01-02 
 *==========================================================================*/

char *TimeToString( time_t tmTime, const char *fmt, 
				int nLenStrTime,OUT char *strTime,)
{
	struct tm gmTime;

	// 
	gmtime_r(&tmTime, &gmTime);
	// convert time to yyyy-mm-dd hh:mm:ss
	strftime(strTime, (size_t)nLenStrTime, fmt, &gmTime);

	return strTime;
}