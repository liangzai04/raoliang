struct _APP_SERVICE
{
#define LEN_SERVICE_NAME		32
#define LEN_SERVICE_LIB			64
	char	szServiceName [LEN_SERVICE_NAME];	//	the name of service
	char	szServiceLib [LEN_SERVICE_LIB];		//	the lib name of service
	int		nServiceType;						//  the type of the service: 
												//  see APP_SERVICE_TYPE_ENUM
	BOOL	bMandatorySerice;					//  TRUE:the service must be OK

	int		nRunType;							// see APP_SERVICE_RUN_TYPE_ENUM

	SERVICE_ARGUMENTS	args;					//	the args to run the serice

	// runtime info, can NOT modify them!!!!
	HANDLE				hServiceLib;			//	the opened lib handle of the *.so

	SERVICE_MAIN_PROC	pfnServiceMain;			//	the serice entry funcatoin
	SERVICE_INIT_PROC	pfnServiceInit;			//  init proc, optional.
	SERVICE_CONFIG_PROC pfnServiceConfig;		//  config proc, optional

				
	HANDLE	hServiceThread;						//	the handle of running service. 
	BOOL	bServiceRunning;					// TRUE for the service is running.
};
typedef struct _APP_SERVICE APP_SERVICE;
static APP_SERVICE	s_pAppService[] =
{
	DEF_APP_SERVICE("GEN_CTL",		"gen_ctl.so",		
		SERVICE_OF_LOGIC_CONTROL,	TRUE,  SERVICE_RUN_AS_TASK),

//#ifdef _HAS_LCD_UI
////#ifdef _HAS_LCD_UI
//DEF_APP_SERVICE("QT_FIFO",		"qt_fifo.so",	
//	SERVICE_OF_LOGIC_CONTROL,	TRUE, SERVICE_RUN_AS_TASK),
	DEF_APP_SERVICE("QT_FIFO",		"qt_fifo.so",			
		SERVICE_OF_LOGIC_CONTROL,	TRUE, SERVICE_RUN_AS_TASK), 
		//#endif //_HAS_LCD_UI
//#endif //_HAS_LCD_UI

    DEF_APP_SERVICE("WEB_UI",		"web_ui_comm.so",	
        SERVICE_OF_USER_INTERFACE,	TRUE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("WEB_USER",		"web_user.so",	
		SERVICE_OF_USER_INTERFACE,	TRUE, SERVICE_RUN_AS_TASK),

	/*DEF_APP_SERVICE("CURL_APP",		"curl_app.so",	
		SERVICE_OF_USER_INTERFACE,	TRUE, SERVICE_RUN_AS_TASK),*/


	DEF_APP_SERVICE("YDN_MIAN",		"ydn23.so",		
		SERVICE_OF_DATA_COMM,		TRUE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("ESR Protocol",		"eem_soc.so",			
		SERVICE_OF_DATA_COMM,		TRUE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("SNMP_MAIN",			"snmp_agent.so",	
		SERVICE_OF_DATA_COMM,		FALSE, SERVICE_RUN_AS_TASK),

	
	DEF_APP_SERVICE("PLC",						"plc.so",			
		SERVICE_OF_LOGIC_CONTROL,	FALSE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("SMS",			"sms.so",			
		SERVICE_OF_LOGIC_CONTROL,	TRUE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("MAIL",			"mail.so",			
		SERVICE_OF_LOGIC_CONTROL,	TRUE, SERVICE_RUN_AS_TASK),

	DEF_APP_SERVICE("MODBUS_MIAN",		"modbus.so",		
		SERVICE_OF_DATA_COMM,		TRUE, SERVICE_RUN_AS_TASK),

	/*DEF_APP_SERVICE("MAINTEN",		"libmaintenance_intf.so",
		SERVICE_OF_MISC,		FALSE, SERVICE_RUN_AS_TASK),*/
};
static BOOL ServiceManager_StartServices(IN OUT SERVICE_MANAGER *pServiceMgr)
{
	for (i = 0; i < pServiceMgr->nService; i++, pService++)
	{
	
			bResult = Service_Start(pService);
		AppLogOut(SERVICE_MGR, 
			(bResult) ? APP_LOG_UNUSED : APP_LOG_ERROR,
			"#%d service \"%s\" is loaded %s. Lib=%p, Main=%p.\n",
			i+1,
			pService->szServiceName,
			(bResult) ? "OK" : "FAIL",
			pService->hServiceLib,
			pService->pfnServiceMain);	
	}
	
	
}
 BOOL Service_Start(IN OUT APP_SERVICE *pService)
{

	//������� lib .so service    �ĳ�ʼ������  main����	  LoadDynamicLibrary  ���� ���ֵ�ƥ��
	const char *pszSymName[] =
	{
		SERVICE_INIT_PROC_NAME,		// "ServiceInit"
		SERVICE_MAIN_PROC_NAME,		// "ServiceMain"
		SERVICE_CONFIG_PROC_NAME,	// "ServiceConfig"
	};

	HANDLE	*pfnProc[ITEM_OF(pszSymName)] =
	{
		(HANDLE *)&pService->pfnServiceInit,
		(HANDLE *)&pService->pfnServiceMain,
		(HANDLE *)&pService->pfnServiceConfig,
	};

	AppLogOut(SERVICE_MGR, APP_LOG_UNUSED,
		"Starting service \"%s\"(%s)...\n",
		pService->szServiceName,
		pService->szServiceLib);

	// check the service is running or not.
	if (Service_IsRunning(pService))
	{
		AppLogOut(SERVICE_MGR, APP_LOG_ERROR,
			"Errors on trying to restart a running service %s(%s).\n",
			pService->szServiceName,
			pService->szServiceLib);
		return FALSE;
	}

	// lock at first.
	LOCK_SERVICE_MGR();

	// load service lib
	pService->hServiceLib = LoadDynamicLibrary(
		pService->szServiceLib,
		ITEM_OF(pszSymName),
		pszSymName,
		pfnProc,
		FALSE);

	if (pService->hServiceLib == NULL)
	{
		AppLogOut(SERVICE_MGR, APP_LOG_ERROR,
			"Fails on loading application service \"%s\"(%s).\n",
			pService->szServiceName,
			pService->szServiceLib);

		UNLOCK_SERVICE_MGR();
		return FALSE;
	}

	if (pService->pfnServiceMain == NULL)
	{
		AppLogOut(SERVICE_MGR, APP_LOG_ERROR,
			"Fails on finding ServiceMain in service \"%s\"(%s).\n",
			pService->szServiceName,
			pService->szServiceLib);

		UnloadDynamicLibrary(pService->hServiceLib);

		pService->hServiceLib    = NULL;
		pService->pfnServiceInit = NULL;
		pService->pfnServiceConfig = NULL;

		UNLOCK_SERVICE_MGR();
		return FALSE;
	}

	// set the running flag for all types of services
	pService->args.nQuitCommand = SERVICE_CONTINUE_RUN;

	// init the serice thread.
	if (pService->pfnServiceInit != NULL)
	{
		pService->args.pReserved = 
			pService->pfnServiceInit(pService->args.argc, pService->args.argv);
	}

	// the service need create a thread to run
	if (pService->nRunType == SERVICE_RUN_AS_TASK)
	{
		// create the run thread
		pService->hServiceThread = RunThread_Create(
			pService->szServiceName,
			(RUN_THREAD_START_PROC)pService->pfnServiceMain,
			(void *)&pService->args,
			&pService->args.dwExitCode,
			RUN_THREAD_FLAG_HAS_MSG);	// create with msg queue.

		if (pService->hServiceThread == NULL)
		{
			AppLogOut(SERVICE_MGR, APP_LOG_ERROR,
				"Fails on creating thread for service \"%s\"...\n",
				pService->szServiceName);
			// do NOT cleanup the  opened service.
			UNLOCK_SERVICE_MGR();
			return FALSE;
		}
	}

	//else the service is run by service manager periodically
	
	pService->bServiceRunning = TRUE;

	AppLogOut(SERVICE_MGR, APP_LOG_UNUSED,//APP_LOG_INFO,
		"Service [%s] started as %s. tid=%p.\n",
		pService->szServiceName,
		(pService->nRunType == SERVICE_RUN_AS_TASK) ? "task" : "dummy",
		pService->hServiceThread);

	UNLOCK_SERVICE_MGR();

	return TRUE;
}



   /* main.c   init_module ����   ServiceManager_Start   ��ʼ�������з���*/
BOOL ServiceManager_Start(IN OUT SERVICE_MANAGER *pServiceMgr)
{
	BOOL	bResult = FALSE;

	AppLogOut(SERVICE_MGR, APP_LOG_UNUSED,
		"Application manager now is starting...\n");

	ZERO_POBJS(pServiceMgr, 1);

	pServiceMgr->hLock = Mutex_Create(TRUE);
	if (pServiceMgr->hLock == NULL)
	{
		AppLogOut(SERVICE_MGR, APP_LOG_WARNING,
			"Failed to create synchronization lock for service mgr.\n");
	}

	//�����ʼ��  
	else if (ServiceManager_LoadServices(pServiceMgr)	    //ͳ����Ҫ���ط�������
		&& ServiceManager_StartServices(pServiceMgr))	    //�������з���
	{
		//�������߳�  ServiceManager_Main  ��ִ�� 
		pServiceMgr->hServiceManager = RunThread_Create(SERVICE_MGR,
			(RUN_THREAD_START_PROC)ServiceManager_Main, pServiceMgr,
			NULL, 0);

		if (pServiceMgr->hServiceManager != NULL)
		{
			bResult = TRUE;
		}
		else
		{
			AppLogOut(SERVICE_MGR, APP_LOG_WARNING,
				"Application manager fails on creating the main thread.\n");
		}
	}

	AppLogOut(SERVICE_MGR, bResult?APP_LOG_UNUSED:APP_LOG_WARNING,
		"Application manager is %s successfully started.\n",
		bResult ? "now" : "NOT");

	return bResult;
}


/*==========================================================================*
 * FUNCTION : ServiceManager_Stop
 * PURPOSE  : 
 * CALLS    : 
 * CALLED BY: called when exit or fails on ServiceManager_Start
 * ARGUMENTS: IN OUT SERVICE_MANAGER  *pServiceMgr : 
 *            IN int nTimeToWaitServiceQuit: unit ms.
 * RETURN   : BOOL : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua(Frank)         DATE: 2004-11-30 20:27
 *==========================================================================*/
BOOL ServiceManager_Stop(IN OUT SERVICE_MANAGER *pServiceMgr, 
						 IN int nTimeToWaitServiceQuit)
{
	AppLogOut(SERVICE_MGR, APP_LOG_UNUSED,
		"Application manager now is quiting...\n");

	//1. stop the service manager.
	if (pServiceMgr->hServiceManager != NULL)
	{
		RunThread_Stop(pServiceMgr->hServiceManager,
			nTimeToWaitServiceQuit, TRUE);
	}

	// 2. stop all services
	ServiceManager_StopServices(pServiceMgr, nTimeToWaitServiceQuit);

	// 3.clean up
    ServiceManager_UnloadServices(pServiceMgr);

	if (pServiceMgr->hLock != NULL)
	{
		Mutex_Destroy(pServiceMgr->hLock);
		pServiceMgr->hLock = NULL;
	}

	return TRUE;
}