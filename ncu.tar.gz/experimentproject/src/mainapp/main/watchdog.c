 /*==========================================================================*
 *    Copyright(c) 2017-2027, ECJTU Co., Ltd.
 *                     ALL RIGHTS RESERVED
 *
 *  PRODUCT  : ACU(Advanced Controller Unit)
 *
 *  FILENAME : main.c
 *  CREATOR  : LiangRao (Lemon)         DATE: 2017-01-02 14:55
 *  VERSION  : V1.00
 *  PURPOSE  : the main proc of ACU, init sys and init app services
 *
 *
 *  HISTORY  :
 *
 *==========================================================================*/
#include "watchdog.h"
#include "public.h"
BOOL WatchDog_Open()
{
	static int s_hWatchDog = -1;
	if (s_hWatchDog != -1)
	{
		return TRUE;	// is already opened.
	}
	TRACEX("Open watch dog...\n");

	s_hWatchDog = open(WATCH_DOG_NAME, O_RDWR);
	if(s_hWatchDog < 0)
	{
		TRACEX("Watchdog Open Err!!!");
		return FALSE;
	}
}