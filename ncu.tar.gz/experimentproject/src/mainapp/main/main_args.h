 #ifndef __MAIN_ARGS_H__
#define __MAIN_ARGS_H__

//int	MainProcess_Args();
#endif 


