#ifndef __WATCHDOG_H__
#define __WATCHDOG_H__
#include "public.h"
BOOL WatchDog_Open();
#endif