	  /*
	  
	  
	  */
void AppLogOut(const char *pTaskName,int iLogLevel,const char *pszFormat,...)
{
	
	
	
	
	
	
}