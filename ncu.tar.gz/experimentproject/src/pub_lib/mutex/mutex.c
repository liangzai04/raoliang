/*��������������ͬһ���߳� ͬ�����ɶ�ʹ��
	int pthread_mutex_init(pthread_mutex_t *restrict mutex, const pthread_mutexattr_t *restric attr);

����int pthread_mutex_destroy(pthread_mutex_t *mutex);

����ͷ�ļ�:

��������ֵ: �ɹ��򷵻�0, �����򷵻ش�����.

����˵��: ���ʹ��Ĭ�ϵ����Գ�ʼ��������, ֻ���attr��ΪNULL. ����ֵ���Ժ󽲽⡣

����2. �������:

�����Թ�����Դ�ķ���, Ҫ�Ի��������м���, ����������Ѿ�������, �����̻߳�����, ֱ��������������. ������˶Թ�����Դ�ķ��ʺ�, Ҫ�Ի��������н�����

��������˵һ�¼�������:

����ͷ�ļ�:

����ԭ��:

����int pthread_mutex_lock(pthread_mutex_t *mutex);

����int pthread_mutex_trylock(pthread_mutex_t *mutex);
*/

struct _MUTEX	//	internal structure for mutex
{				
	pthread_mutex_t	hInternalMutex;	//	the mutex lock
//	pthread_cond_t	hInternalCond;	//	the waitable condition
};				

typedef struct _MUTEX	MUTEX;

/*==========================================================================*
 * FUNCTION : Mutex_Create
 * PURPOSE  : Create a mutex
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN BOOL  bOpenedLock : TRUE: the lock is opened, 
 *                                   FALSE: lock will be locked by the creator
 * RETURN   : HANDLE : NULL: failure, others: the handle of the mutex
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-04 15:13
 *==========================================================================*/
HANDLE Mutex_Create(IN BOOL bOpenedLock)
{
	MUTEX			*pMutex = NEW( MUTEX, 1 );
	pthread_mutex_t mut		= PTHREAD_MUTEX_INITIALIZER;

	if (pMutex == NULL)
	{
#ifdef _DEBUG_MUTEX
	TRACE("[Mutex_Create] -- out of memory on new a MUTEX.\n");
#endif //_DEBUG_MUTEX

	return NULL;
	}

	pMutex->hInternalMutex = mut;
	
	// To lock the mutext if want to created a locked mutext
	if (!bOpenedLock)
	{
		Mutex_Lock((HANDLE)pMutex, 0);
	}
	
	return (HANDLE)pMutex;
}
int Mutex_Lock(IN HANDLE hm, IN DWORD dwWaitTimeout)
{
	MUTEX	*pMutex = (MUTEX *)hm;
	double	tEnd, tLast, tNow;

#define WAIT_LOCK_INTERVAL	20000	// 20 ms
	
	if (hm == NULL)
	{
		return ERR_INVALID_ARGS;
	}

#ifdef _DEBUG_MUTEX
	TRACE("[Mutex_Lock] -- lock and wait %d ms at %d\n", 
		(int)dwWaitTimeout, (int)time(NULL));
#endif //_DEBUG_MUTEX

	tEnd = GetCurrentTime() + (double)dwWaitTimeout/1000.0;

	for (;;)
	{
		if (pthread_mutex_trylock(&pMutex->hInternalMutex) == 0)
		{
			return ERR_MUTEX_OK;
		}

		// to test timeout.
		tNow = GetCurrentTime();
		if (tNow >= tEnd)
		{
			break;
		}

		// trigger heartbeart
		if (((int)tNow - (int)tLast) >= MAX_WAIT_INTERVAL)
		{
			RUN_THREAD_HEARTBEAT();
			tLast = tNow;
		}
			
		// sleep a while to try, always use the interval 20 ms
		usleep(WAIT_LOCK_INTERVAL);	// unit is us
	}

	return ERR_MUTEX_TIMEOUT;
}

void Mutex_Unlock(HANDLE hm)
{
	if (hm != NULL)
	{
		pthread_mutex_unlock(&((MUTEX *)hm)->hInternalMutex);
	}
}


/*==========================================================================*
 * FUNCTION : Mutex_Destroy
 * PURPOSE  : To destroy a mutex, the mutext can not be used.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN HANDLE  hm : The HANDLE of mutext will be destroyed
 * RETURN   : void : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-04 16:19
 *==========================================================================*/
void Mutex_Destroy(IN HANDLE hm)
{
	if (hm != NULL)
	{
		pthread_mutex_destroy(&((MUTEX *)hm)->hInternalMutex);
		DELETE( hm );
	}
}




/*�ź�����������һ���ط���������һ���ط��ͷţ���ʼֵΪ0, ��������0�������ʣ��ź����������ڵ��̹߳�����ȫ�ֱ������߾�̬����һ������Դ����ʹ����+1\
A->B    A sem_post   B:sem_wait

sem_init();
sem_wait();
sem_post();
*/
struct _SEMAPHORE	//	internal structure for semaphore
{				
	sem_t	hInternalSem;	//	the semaphore lock
};				

typedef struct _SEMAPHORE	SEMAPHORE;

/*==========================================================================*
 * FUNCTION : Sem_Create
 * PURPOSE  : Create a semaphore
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN int  nInitValue : the value of semaphore at init
 * RETURN   : HANDLE : NULL: failure, others: the handle of the semaphore
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-14 15:13
 *==========================================================================*/
HANDLE Sem_Create(IN int  nInitValue)
{
	SEMAPHORE	*pSem = NEW(SEMAPHORE, 1);

	if (pSem == NULL)
	{
#ifdef _DEBUG_MUTEX
		TRACE("[Sem_Create] -- out of memory on new a SEMAPHORE.\n");
#endif //_DEBUG_MUTEX

		return NULL;
	}

	// no share, start count is 0 
	sem_init(&pSem->hInternalSem, 0, (unsigned int)nInitValue);
	
	return (HANDLE)pSem;
}
int Sem_Wait(IN HANDLE hSem, IN DWORD dwWaitTimeout)
{
	SEMAPHORE	*pSem = (SEMAPHORE *)hSem;
	double	tEnd, tLast, tNow;
	HANDLE	hSelf;

#define WAIT_LOCK_INTERVAL	20000	// 20 ms
	
	if (hSem == NULL)
	{
		return ERR_INVALID_ARGS;
	}

#ifdef _DEBUG_MUTEX
	TRACE("[Sem_Wait] -- %p wait %d ms at %d\n", 
		RunThread_GetId(NULL), (int)dwWaitTimeout, (int)time(NULL));
#endif //_DEBUG_MUTEX

	tEnd = GetCurrentTime() + (double)dwWaitTimeout/1000.0;

	for (;;)
	{
		RunThread_Heartbeat(hSelf);

		if (sem_trywait(&pSem->hInternalSem) == 0)
		{
			return ERR_MUTEX_OK;//lock ok
		}

		//continue to try to lock.

		// to test timeout.
		tNow = GetCurrentTime();
		if (tNow >= tEnd)
		{
			break;
		}

		// trigger heartbeart
		TRACE("tLast1 is %d!!!\n", tLast);
		if (((int)tNow - (int)tLast) >= MAX_WAIT_INTERVAL)
		{
			RUN_THREAD_HEARTBEAT();
			tLast = tNow;
		}
			
		// sleep a while to try, always use the interval 20 ms
		usleep(WAIT_LOCK_INTERVAL);	// unit is us
	}

#ifdef _DEBUG_MUTEX
	TRACE("[Sem_Wait] -- wait timeouted at %d\n", 
		(int)time(NULL));
#endif //_DEBUG_MUTEX

	return ERR_MUTEX_TIMEOUT;
}
#endif


/*==========================================================================*
 * FUNCTION : Sem_Post
 * PURPOSE  : Release the semaphore.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hSem : 
 * RETURN   : void : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-04 20:13
 *==========================================================================*/
void Sem_Post(HANDLE hSem, int nPostCount)
{
	if (hSem != NULL)
	{
		while (nPostCount-- > 0)
		{
			if (sem_post(&((SEMAPHORE *)hSem)->hInternalSem) != 0)
			{
				break;
			}
		}
	}
}


/*==========================================================================*
 * FUNCTION : Sem_Destroy
 * PURPOSE  : To destroy a semaphore, the semaphore can not be used.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN HANDLE  hSem : The HANDLE of semaphore will be destroyed
 * RETURN   : void : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-14 16:19
 *==========================================================================*/
void Sem_Destroy(IN HANDLE hSem)
{
	if (hSem != NULL)
	{
		sem_destroy(&((SEMAPHORE *)hSem)->hInternalSem);
		DELETE( hSem );
	}
}





