#ifndef __QUEUE_H__
#define __QUEUE_H__
#define LOCK(pLock)			pthread_mutex_lock((pLock))
#define UNLOCK(pLock)		pthread_mutex_unlock((pLock))
#define DESTROY_LOCK(pLock) pthread_mutex_destroy((pLock))