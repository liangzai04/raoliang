#include "queue.h"
#define LOCK(pLock)			pthread_mutex_lock((pLock))
#define UNLOCK(pLock)		pthread_mutex_unlock((pLock))
#define DESTROY_LOCK(pLock) pthread_mutex_destroy((pLock))

#define QUEUE_MOVE_AHEAD( q, x )	\
	( ((x) < (q)->nCharCapacity) ? ((x) + (q)->nSize) : 0 )

#define QUEUE_MOVE_BACK( q, x )	\
	( ((x) > 0) ? ((x) - (q)->nSize) : ( (q)->nCharCapacity) )
/*���е�ʹ�ã�
1.��ʼ�� ���г���
a.�����head  �������ݣ� ���������ݺ���QUEUE_MOVE_BACK���nhead >0 �� ����ͷ�пռ䣬nhead --��nhead =0�� ����ͷû�пռ� nhead=nCharCapacity��head�Ƶ��������һ�����ݴ���
b.    �����tail�������ݣ�����������ǰ�ƣ�	QUEUE_MOVE_AHEAD  ���  tail<	 nCharCapacity,û�е�������ĩ�ˣ�tail++,�����������ĩ�ˣ���tail �ƶ���������ǰ��0����
c.��ͷ��ȡ���ݣ� QUEUE_MOVE_AHEAD    ���	nhead     ��������β������һ������Ӧ�ô�����ͷ0��ʼȡ	���� nhead++
d.       ��β��ȡ����   QUEUE_MOVE_BACK     ntail ������ͷ������ tail �Ƶ�����ĩ�˿�ʼ�ݼ���else  �ݼ�
*/

struct _QUEUE
{
	int		nIncStep;	//	The nIncStep to indicate wthether the queue 
						//  capacity can be auto enlarged or not.
	int		nElementSize;		//	size of an element or a record of this queue
	int		nCapacity;	//	max elements of the queue
	char	*pBuffer;	//	the buffer to hold elements
	pthread_mutex_t	hSyncLock;	//	the mutex lock

	int		nCount;			//	the current elements in the queue

	int		nCharCapacity;	//	equal to (nCapacity-1)*nSize in char
	int		nHead;			//	the first char of the head position
	int		nTail;			//	the first char of the tail empty position

	HANDLE	hCountSem;		// the semaphore for the count.			
}
HANDLE Queue_Create(int iMaxCapacity, int iElementSize,int	nIncStep)
{
	Queue *q;
	assert(	iMaxCapacity>0 && iElementSize>0 &&  nIncStep>0);
	//malloc  space for queue
	q=NEW(queue,1);
	if(NULL == q)
	{
		TRACEX("New queue Fail!!!");    	    
		return NULL;
	}
	q->pBuffer=NEW(char,     iMaxCapacity*iElementSize);
	if(NULL == q->pBuffer)
	{
		freee(p);	
	}

	// create the semaphore
	q->hCountSem = Sem_Create(0);// no share, start count is 0 
	if( q->hCountSem == NULL )
	{
		DELETE(q->pBuffer);
		DELETE( q );
		return NULL;		
	}
      INIT_LOCK( &q->hSyncLock );

	q->nCapacity = iMaxCapacity;
	q->nSize     = iElementSize;
	q->nCount    = 0;
	q->nCharCapacity = (q->nCapacity-1) * q->nSize;
	q->nHead     = 0;
	q->nTail     = 0;
	q->nIncStep  = nIncStep;

	return (HANDLE)q;
	
}
/*==========================================================================*
 * FUNCTION : Queue_Destroy
 * PURPOSE  : To destroy a initialized queue.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hq : 
 * RETURN   : void : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-05 20:12
 *==========================================================================*/
void Queue_Destroy(HANDLE hq)
{
	QUEUE *q = (QUEUE *)hq;

	if( q == NULL )
	{
		return;
	}

#ifdef _DEBUG_RUN_QUEUE
	if (q->nCount != 0)
	{
		TRACE("[Queue_Destroy] -- A non-empty queue will be deleted.\n");
	}
#endif //_DEBUG

	free( q->pBuffer );

	DESTROY_LOCK(&q->hSyncLock);
	Sem_Destroy(q->hCountSem);

	free( q );
}

// 0: ok, -1: error, 1: full.
/*==========================================================================*
 * FUNCTION : Queue_Put
 * PURPOSE  : To put a element to a queue
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hq        : 
 *            void    *pElement : 
 *            BOOL    bUrgent   : 
 * RETURN   : int : ERR_QUEUE_OK: OK, ERR_QUEUE_FULL: full, 
 *                  ERR_INVALID_ARGS: error arg,  ERR_NO_MEMORY: no memory
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-05 20:17
 *==========================================================================*/
int Queue_Put( HANDLE hq, void *pElement, BOOL bUrgent )
{
#define ERR_QUEUE_OK     0        
#define ERR_QUEUE_FULL 1
#define ERR_QUEUE_MEMFAIL 1
	int nQueueSta;
	QUEUE *q=(QUEUE*)hq;
	assert(q != NULL && pElement!=NULL);
	LOCK(&q->hSyncLock);
	if(q->nCount >= q->nCapacity)	   //queue full enlarge queue
	{
		if(q->nIncStep > 0)	// auto increase the queue.
		{
			int	 nNewCharSize = (q->nCapacity+q->nIncStep)*q->nSize;	
			char *pNewBuffer  = NEW(char, nNewCharSize);
			if(	pNewBuffer !=NULL)
			{
				size_t      nheadtoEnd;
				//enlarge queue from the tail
				//  1.head>tail [7][8][9][][][][][][0][1][2]
				//2   head <=tail[0][1][2]����[7][8][9][][][][][][]
				if(q->nHead >q->nTail)
				{
					//move buf[0]~ntail to  newbufp0]
					memcpy( &pNewBuffer[0],   q->pBuffer,(size_t)q->nTail);
					//move head~nCapacity to the end 
					nheadtoEnd=(size_t)(q->nCapacity*q->nSize - q->nHead);
					memcpy(&pNewBuffer[nNewCharSize-nheadtoEnd],&q->pBuffer[q->nHead],nheadtoEnd)    ;
					q->nHead += q->nIncStep*q->nSize;
					free(pNewBuffer);
					q->pBuffer	 = pNewBuffer;
					q->nCapacity += q->nIncStep;
					q->nCharCapacity = (q->nCapacity-1) * q->nSize;
				}
				else
				{
					nQueueSta    = ERR_QUEUE_MEMFAIL;
				}
				
			}
		}
		else
		{
			nQueueSta    = ERR_QUEUE_FULL;	
			
		}     
	}
       else	  //queue has empty entry
	{
		if( bUrgent == FALSE )	// insert to tail
		{
			// copy data
			memmove( &q->pBuffer[q->nTail], pElement, 
				(size_t)q->nSize );

			// set tail position to the next empty.
			q->nTail = QUEUE_MOVE_AHEAD( q, q->nTail );
		}
		else	// insert to head
		{
			// make the head to back, which is an empty position
			q->nHead = QUEUE_MOVE_BACK( q, q->nHead );

			// copy data
			memmove( &q->pBuffer[q->nHead], pElement, 
				(size_t)q->nSize );
		}

		q->nCount++;

		nResult = ERR_QUEUE_OK;
		//queue data can be access num ++       queue_get
		Sem_Post(q->hCountSem, 1);     
	}
	UNLOCK( &q->hSyncLock );

	return nResult;
}

/*==========================================================================*
 * FUNCTION : Queue_Get
 * PURPOSE  : get an element from the queue.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hq        : 
 *            void    *pElement : 
 *            BOOL    bPeek     : TRUE: only get the element, the element
 *                                will not be deleted.
 *            DWORD dwTimeout   : wait for n ms if no data.
 * RETURN   : int : ERR_OK for OK, or ERR_QUEUE_EMPTY for empty queue
 *                  or ERR_INVALID_ARGS
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-05 20:58
 *==========================================================================*/
int Queue_Get(HANDLE hq, void *pElement, BOOL bPeek, DWORD dwTimeout)
{
	QUEUE *q = (QUEUE *)hq;
	int	nResult;
	 assert((q != NULL) && ( pElement @= NULL) );
	//1. to test there is any data or not.
	if (Sem_Wait(q->hCountSem, dwTimeout) != ERR_MUTEX_OK)
	{
		return ERR_QUEUE_EMPTY;
	}
	ASSERT(q->nCount > 0);

	// 2. to get the data.
	LOCK( &q->hSyncLock );
	if (q->nCount > 0)
	{
		// copy data
		memmove( pElement, &q->pBuffer[q->nHead], (size_t)q->nSize );

		if( !bPeek )
		{
			// move pos and descrease count
			q->nHead = QUEUE_MOVE_AHEAD( q, q->nHead );
			q->nCount --;
		}

		nResult = ERR_QUEUE_OK;
	}
	else	// Q is empty
	{
		nResult = ERR_QUEUE_EMPTY;
	}

	UNLOCK( &q->hSyncLock );

	if (bPeek)
	{
		// we only peek, increase the semaphore again.
		Sem_Post(q->hCountSem, 1);
	}

	return nResult;
}
