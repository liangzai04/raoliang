#include "run_thread.h"

/*  �̹߳������ԣ�
1.�����̹߳������� ����ϵͳ������ͨ�� RunThread_Create �����뵽pThreadEntries��_RUN_THREAD_MANAGER����������
2.ServiceManager  Ҳ��ͨ��	  RunThread_Create ��������pThreadEntries��ͬʱServiceManager���������ÿ��lib �� services��
	һ��һ��service�˳���	      ServiceManager ���߳�Ҳ���˳���
	�������      ServiceManager�˳��ˣ�����app���˳�
����߳� �˳���pthread_self��ȡ��������ID ���޷� �Ը��߳�ι�����Ӷ����³�ʱ
3.	  ÿ���߳� ��һ����	�������������ڴ������߳�ǰ�������ڴ����߳���ɺ�������Ӷ�ȷ���̴߳�����
ԭ���ԣ�ÿ���߳���һ���Լ�����Ϣ�������̼߳���պͷ�����Ϣ   ��Ҳ����Ҫ������ Queue_Get  Queue_put
4. �߳�ͨ��  RunThread_HookEntry  ���߳�ִ������˳�������߳���Դ��
.*/
#define THREAD_ENTRY_INC_STEP	32	// The step to increase the pThreadEntries

#define RUN_THREAD_IS_VALID(pEntry)	((pEntry)->dwThreadId != 0)
#define RENEW(T,pold,num)	 (T*)realloc(pold,sizeof(T)*num)
#define NEW(T, nItems)		(T *)malloc( sizeof(T)*(nItems) )
#define ZERO_POBJS(p, n)	memset((p), 0, (n)*sizeof(*(p)))

 
static RUN_THREAD_MANAGER	s_runMgr =
{
	0,							//nThreadEntries
	NULL,						//pThreadEntries
	0,							//nRunningThreads
	NULL,						//pfnEventHandler
//	PTHREAD_MUTEX_INITIALIZER,  //mutex
	PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP,// can be locked recursively
	0,							//nLastEmptyEntry
	0,							//hManagerThread
#ifdef THREAD_MANAGER_AS_SPECIAL
	RUN_THREAD_IS_INVALID		//nStatus:
#endif
};
//�̹߳�������
 #define PMGR_SYNC_LOCK			&s_runMgr.hSyncLock
#define LOCK_THREAD_MANAGER()   pthread_mutex_lock(PMGR_SYNC_LOCK)
#define UNLOCK_THREAD_MANAGER() pthread_mutex_unlock(PMGR_SYNC_LOCK)
//����ÿ���̵߳��߳���
#define LOCK_THREAD_SYNC(p)       pthread_mutex_lock(&((p)->hSyncLock))
#define UNLOCK_THREAD_SYNC(p)     pthread_mutex_unlock(&((p)->hSyncLock))
#define DESTROY_THREAD_SYNC(p)    pthread_mutex_destroy(&((p)->hSyncLock))
/*==========================================================================*
 * FUNCTION : RunThread_EnlargeEntries
 * PURPOSE  : 
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN int  nEntryToAdd : 
 * RETURN   : static BOOL : 
 * COMMENTS : The thread manager must be locked before calling this
 * CREATOR  : raoliang               DATE: 2017-04-10 09:33
 *==========================================================================*/
static BOOL RunThread_EnlargeEntries(IN int nEntryToAdd)
{
	RUN_THREAD_ENTRY	*pNewEntries;
	int					nNewEntries;

	nNewEntries = s_runMgr.nThreadEntries+nEntryToAdd;

	// to enlarge the entry buffer
	pNewEntries = RENEW(RUN_THREAD_ENTRY, 
		s_runMgr.pThreadEntries, nNewEntries);
	if (pNewEntries == NULL)
	{
		return FALSE;
	}

	ZERO_POBJS(&pNewEntries[s_runMgr.nThreadEntries], 
		nNewEntries);	// clean the new allocated buffer

	s_runMgr.pThreadEntries = pNewEntries;	// set new entry ptr.
	s_runMgr.nThreadEntries = nNewEntries;

	return TRUE;
}
/*==========================================================================*
 * FUNCTION : RunThread_ReleaseEntry
 * PURPOSE  : Release a unused entry, to destroy the msg queue and set dwThreadId
 *            to 0.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: RUN_THREAD_ENTRY  *pEntry : 
 * RETURN   : static void : 
 * COMMENTS : must lock the manager before calling this function.
 * CREATOR  : Mao Fuhua                DATE: 2004-10-10 09:19
 *==========================================================================*/
static void RunThread_ReleaseEntry(IN OUT RUN_THREAD_ENTRY *pEntry)
{
	if (pEntry == NULL)
	{
#ifdef _DEBUG_RUN_THREAD
		TRACE("[RunThread_ReleaseEntry] -- Try to release a NULL entry.\n");
#endif //_DEBUG_RUN_THREAD

		return;
	}

	// to release the queue.
	if (pEntry->hMsgQueue != NULL)
	{
		Queue_Destroy(pEntry->hMsgQueue);
		pEntry->hMsgQueue = NULL;
	}

	pEntry->nStatus = RUN_THREAD_IS_INVALID;

	s_runMgr.nLastEmptyEntry = GET_THREAD_INDEX(pEntry->dwThreadId);
	s_runMgr.nRunningThreads--;		// the running thread num

#ifdef _DEBUG_RUN_THREAD
	TRACEX("Current running threa num is %d.\n", s_runMgr.nRunningThreads);
#endif //_DEBUG_RUN_THREAD

	pEntry->dwThreadId = 0;			// release it


/*==========================================================================*
 * FUNCTION : RunThread_GetEmptyEntry
 * PURPOSE  : get an empty thread entry from manager
 * CALLS    : 
 * CALLED BY: RunThread_Create
 * RETURN   : static int : -1: for fail. other is the index of the entry.
 * COMMENTS : The thread manager must be locked before calling this function
 * CREATOR  : raoliang                DATE: 2017-04-09 19:16
 *==========================================================================*/
static int RunThread_GetEmptyEntry(void)
{
      RUN_THREAD_ENTRY *pEntry;
	int iEntryIndex;
	//need enlarge  thread enerty queue
	if (s_runMgr.nRunningThreads >= s_runMgr.nThreadEntries)
	{
		if (!RunThread_EnlargeEntries(THREAD_ENTRY_INC_STEP))
		{
			TRACEX("EnLarge  thread enerty Fail!!!\n");
			return -1;
		}
	}
	// entry may be released nLastEmptyEntry =INDEX(pEntry->dwThreadId) 
	//if	   s_runMgr.nLastEmptyEntry  <	 s_runMgr.nThreadEntries    means  one dwThreadId we can just search start from this id
	//����ʹ���ϴ��ͷŵ�entry
	iEntryIndex= 0;
	pEntry = &s_runMgr.pThreadEntries[i];
	while(RUN_THREAD_IS_VALID(pEntry))
	{
		iEntryIndex++;
		pEntry = &s_runMgr.pThreadEntries[iEntryIndex];
	}
	// we simply consider the next entry is free.  �������ҵ�Ч�ʾͻ�ܸ�
	s_runMgr.nLastEmptyEntry = iEntryIndex+1;
	s_runMgr.nRunningThreads++;	// increase the running thread num
	return iEntryIndex;
}
/*==========================================================================*
 * FUNCTION : RunThread_InitThread
 * PURPOSE  :new a emptythreadentry and init 
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hThread : 
 * RETURN   : int : RUN_THREAD_IS_RUNNING if running, else 
 *                  RUN_THREAD_IS_INVALID for invalid thread(or not running)
 *                  RUN_THREAD_TO_QUIT for the thread need to quit.
 * COMMENTS : 
 * CREATOR  : raoliang                DATE: 2017-04-17 15:40
 *==========================================================================*/
HANDLE RunThread_InitThread( const char *pszThreadName,
						void *pfnThreadProc,
						void *pThreadArg,
						DWORD *pdwExitCode,
						BOOL bCreateMsgQueue)
{
#define RUN_THREAD_MAX_MSG 50	//	the maximum msg can be hold in each thread
	int					 nEntryId;
	RUN_THREAD_START_ARG *pArg;
	RUN_THREAD_ENTRY	 *pEntry;
	pthread_mutex_t		 hSyncLockInit = PTHREAD_MUTEX_INITIALIZER;

	assert(pfnThreadProc != NULL);

	//get an entry from	     thread entry
	nEntryId = RunThread_GetEmptyEntry();
	if(nEntryId<0)
	{
		TRACEX("int  thread  entry Fail!!!");	
		
	}
	pArg = NEW(RUN_THREAD_START_ARG, 1);
	if(bCreateMsgQueue)
	{
		pEntry->hMsgQueue =Queue_Create(
				RUN_THREAD_MAX_MSG,
				sizeof(RUN_THREAD_MSG),
				0)
		if( NULL == pEntry->hMsgQueue)
		{
			    free(pArg);
			    return NULL;
		}	
	}
	else
	{
		pEntry->hMsgQueue = NULL;
	}
	if( pszThreadName == NULL)
	{
		strncpy(pEntry->szThreadName, "", 
		sizeof(pEntry->szThreadName));
	}
	else
	{
		strncpy(pEntry->szThreadName, pszThreadName, 
		sizeof(pEntry->szThreadName));
	}
	// give 2 heartbeat.
	pEntry->dwThreadHeartbeat = RUN_THREAD_INIT_HEARTBEATS;
	pEntry->dwThreadId = MAKE_THREAD_ID(nEntryId);
	pEntry->nStatus    = RUN_THREAD_IS_RUNNING;

	// init the startup arg
	pArg->hSyncLock     = hSyncLockInit;

	pArg->hThread       = (HANDLE)pEntry->dwThreadId;
	pArg->pdwExitCode   = pdwExitCode;
	pArg->pfnThreadProc = pfnThreadProc;
	pArg->pThreadArg    = pThreadArg;

	return pArg;
	
}
 /*==========================================================================*
 * FUNCTION : RunThread_HookEntry
 * PURPOSE  : The run thread hook proc.
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: RUN_THREAD_START_ARG  *pArg : 
 * RETURN   : static void *: 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-09 20:37
 *==========================================================================*/
static void *RunThread_HookEntry(IN RUN_THREAD_START_ARG *pArg)
{
	RUN_THREAD_START_PROC pfnThreadProc = pArg->pfnThreadProc;// start proc
	void	  *pThreadArg   = pArg->pThreadArg;	// start arg
	DWORD	  *pdwExitCode  = pArg->pdwExitCode;// exit code ptr.
	HANDLE	  hSelf			= pArg->hThread;
	DWORD	  dwExitCode;

	char		szThreadName [LEN_RUN_THREAD_NAME];

	strncpy(szThreadName, pArg->pEntry->szThreadName, 
		sizeof(szThreadName));

	TRACEX("Thread %s(ThreadID=%p,ProcessID=%d) started. Now total threads is %d\n",
		szThreadName, hSelf, getpid(), s_runMgr.nRunningThreads);

	// set the thread is cancelable
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	
	//set the thread can be canceled immediately
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    // Sync. do NOT continue, till creator work done.
	LOCK_THREAD_SYNC(pArg);	      //�ȴ��̴߳������

	DESTROY_THREAD_SYNC(pArg);  // remove lock, it's no use.
	DELETE(pArg);				// delete the memory.

	// to run the thread routine now.
	dwExitCode = pfnThreadProc(pThreadArg);

	// the thread run done, release the entry to free.
	LOCK_THREAD_MANAGER();	// lock the thread manager data structure.

	if (pdwExitCode != NULL)	// save the exit code.
	{
		//RunThread_SetExitCode(hSelf, dwExitCode, pdwExitCode);
		*(pdwExitCode) = (dwExitCode) ;
	}

	RunThread_ReleaseEntry(&s_runMgr.pThreadEntries[GET_THREAD_INDEX(hSelf)]);

	UNLOCK_THREAD_MANAGER();

	return (void *)dwExitCode;
}

 /*==========================================================================*
 * FUNCTION : RunThread_Create
 * PURPOSE  : create one thread and add thread to threadenerties ,so thread manager can management them
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hThread : 
 * RETURN   : int : RUN_THREAD_IS_RUNNING if running, else 
 *                  RUN_THREAD_IS_INVALID for invalid thread(or not running)
 *                  RUN_THREAD_TO_QUIT for the thread need to quit.
 * COMMENTS : 
 * CREATOR  : raoliang                DATE: 2017-04-17 15:40
 *==========================================================================*/
HANDLE RunThread_Create( const char *pszThreadName,
						void *pfnThreadProc,
						void *pThreadArg,
						DWORD *pdwExitCode,
						DWORD dwCreateFlag)
{
	HANDLE					hThread = NULL;
	RUN_THREAD_START_ARG	*pArg;
	// get a empty thread entry and init the thread startup argument
	pArg = RunThread_InitThread(pszThreadName, 
		pfnThreadProc,
		pThreadArg,
		pdwExitCode,
		dwCreateFlag);
	if( pArg != NULL)
	{
		RUN_THREAD_ENTRY *pEntry;
		//get low  16 bits            nEntryId
		pEntry = &s_runMgr.pThreadEntries[GET_THREAD_INDEX(pArg->hThread)];
		// lock the sync lock at first.
		LOCK_THREAD_SYNC(pArg);
		if (pthread_create( &pEntry->hSystemThread, 
			NULL,//&attr
			(PTHREAD_START_ROUTINE)RunThread_HookEntry,
			(void *)pArg) == 0)
		{
			hThread = (HANDLE)pEntry->dwThreadId;

			// create the thread OK. detach the thread
			pthread_detach(pEntry->hSystemThread);

			UNLOCK_THREAD_SYNC(pArg); // sync. let thread to go.
			
			TRACE("Thread %s was created, Thread Id = %08x.\n",
				pszThreadName, hThread);
		}
		else
		{
			RunThread_ReleaseEntry(pEntry);
			DESTROY_THREAD_SYNC(pArg);  // remove lock, it's no use.
			free(pArg);		
		}
		
	}
	UNLOCK_THREAD_MANAGER();
	return hThread;
}
 /*==========================================================================*
 * FUNCTION : RunThread_GetStatus
 * PURPOSE  : get the running state of a thread
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: HANDLE  hThread : 
 * RETURN   : int : RUN_THREAD_IS_RUNNING if running, else 
 *                  RUN_THREAD_IS_INVALID for invalid thread(or not running)
 *                  RUN_THREAD_TO_QUIT for the thread need to quit.
 * COMMENTS : 
 * CREATOR  : raoliang                DATE: 2017-04-17 15:40
 *==========================================================================*/
int RunThread_GetStatus(IN HANDLE hThread)
{
	RUN_THREAD_ENTRY *pEntry;

	LOCK_THREAD_MANAGER();	// lock the thread manager data structure.

	// test the thread id is valid or not
	pEntry = RunThread_GetEntryById(hThread);

	UNLOCK_THREAD_MANAGER();
	return (pEntry != NULL) ? pEntry->nStatus : RUN_THREAD_IS_INVALID;
}

/*==========================================================================*
 * FUNCTION : RunThread_CancelThreads
 * PURPOSE  : 
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: IN OUT RUN_THREAD_ENTRY  *pEntry : 
 *            IN int                   nEntry  : 
 * RETURN   : static int :
 * COMMENTS :  the manager shall be locked at first!
 * CREATOR  : Mao Fuhua                DATE: 2004-10-13 18:21
 *==========================================================================*/
static int RunThread_CancelThreads(IN OUT RUN_THREAD_ENTRY *pEntry,
							IN int nEntry)
{
	int nStatus;

	if (pEntry == NULL)
	{
		return ERR_THREAD_KILLED;
	}


	for (; nEntry > 0; nEntry--, pEntry++)
	{
		if (RUN_THREAD_IS_VALID(pEntry))
		{
			switch(pthread_cancel(pEntry->hSystemThread))
			{
			case 0:		// ok
#ifdef _DEBUG_RUN_THREAD
				TRACE( "[RunThread_CancelThreads] -- Thread %s(%p) is canceled.\n",
					pEntry->szThreadName, (HANDLE)pEntry->dwThreadId);
#endif //_DEBUG_RUN_THREAD
				//break;	//! No break here

			case ESRCH:	// it has stopped
 				RunThread_ReleaseEntry(pEntry);
				nStatus = ERR_THREAD_KILLED;
				break;

			default:
				nStatus = ERR_THREAD_STILL_RUNNING;
			}
		}
	}

	return nStatus;
}

/*==========================================================================*
 * FUNCTION : RunThread_ProcessThreadEvent
 * PURPOSE  : 
 * CALLS    : 
 * CALLED BY: 
 * ARGUMENTS: DWORD              dwEvent  : 
 *            RUN_THREAD_ENTRY  *pEntry : 
 * RETURN   : static int : 
 * COMMENTS : 
 * CREATOR  : Mao Fuhua                DATE: 2004-10-10 14:35
 *==========================================================================*/
static int RunThread_ProcessThreadEvent(IN DWORD dwEvent, 
										IN OUT RUN_THREAD_ENTRY *pEntry)
{
	int rc;
	int nEntry;
//	RUN_THREAD_MSG msg;

	rc = s_runMgr.pfnEventHandler(dwEvent, 
		(HANDLE)pEntry->dwThreadId,	pEntry->szThreadName);

	switch (rc)
	{
	case THREAD_CONTINUE_RUN:
		return rc;

	case THREAD_CANCEL_THIS:
		{
			nEntry = 1;
		}
		break;

	case THREAD_CANCEL_ALL:
		{
			pEntry = s_runMgr.pThreadEntries;
			nEntry = s_runMgr.nThreadEntries;
		}
		break;

	default:
		return rc;
	}

	//to KILL the threads
	RunThread_CancelThreads(pEntry, nEntry);

	return rc;
}

static DWORD RunThread_Manager(IN void *pArgNoUse )
{

	HANDLE			 hMgr;	
	TRACE("[RunThread_Manager] -- thread manager started.\n");
	// set the thread is cancelable
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	
	//set the thread can be canceled immediately
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
	hMgr = RunThread_GetId(NULL);
	assert(hMgr!=NULL);
#define RUN_THREAD_MANAGER_IS_RUNNING() \
			(RunThread_GetStatus(hMgr) == RUN_THREAD_IS_RUNNING)
	while (RUN_THREAD_MANAGER_IS_RUNNING())
	{
		//�������״̬���ȴ������̴߳�����ʼ����ɣ�
		t = RUN_THREAD_HEARTBEAT_CHECK_INTERVAL;
		
		// wait for a period before to check heartbeat.
		while ((t > 0) && RUN_THREAD_MANAGER_IS_RUNNING())
		{
			s_runMgr.pfnEventHandler(THREAD_EVENT_HEARTBEAT, NULL,
				NAME_THREAD_MANAGER);

			Sleep(RUN_THREAD_MANAGER_HEARTBEAT_INTERVAL);
			t -= RUN_THREAD_MANAGER_HEARTBEAT_INTERVAL;
		}
		LOCK_THREAD_MANAGER();	// lock the thread manager data structure.
		
		pEntry = s_runMgr.pThreadEntries;
		for (t = 0; t < s_runMgr.nThreadEntries; t++, pEntry++)
		{
			if (RUN_THREAD_IS_VALID(pEntry) && 
				(pEntry->dwThreadHeartbeat == 0)) // no heartbeat!
			{
				RunThread_ProcessThreadEvent(THREAD_EVENT_NO_RESPONSE, 
					pEntry);
			}

			pEntry->dwThreadHeartbeat = 0;
		}
		UNLOCK_THREAD_MANAGER();
	}	

	 return 0;
}
int Run_Thread_ManagerInit(RUN_THREAD_EVENT_HANDLER pfnEventHandler)
{
	 if( pfnEventHandler ==NULL)
	{
		return -1;
	}
	 s_runMgr.pfnEventHandler = pfnEventHandler;
	if (!RunThread_EnlargeEntries(THREAD_INIT_ENTRY))
	{
		TRACEX("test log \n");
		TRACEX("enlarge thread entries Error!!!\n");	
	}
	s_runMgr.hManagerThread  = RunThread_Create("THREAD_MGR",
		RunThread_Manager,
		NULL,
		NULL,
		0);	
	if (s_runMgr.hManagerThread == NULL)
	{
		return -1;
	}
	return 0;
}

