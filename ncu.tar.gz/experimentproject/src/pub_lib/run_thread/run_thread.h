#ifndef __RUN_THREAD_H__
#define __RUN_THREAD_H__
#include<pthread.h>
  // status of run thread
#define RUN_THREAD_IS_RUNNING		0	// is running
#define RUN_THREAD_TO_QUIT			1	// thread need to quit.
#define RUN_THREAD_IS_INVALID		2	// the thread is invalid
struct _RUN_THREAD_MANAGER	//	The run-thread manager
{				
	int	  	 	            nThreadEntries;		//max threads can be created
	RUN_THREAD_ENTRY		*pThreadEntries;	//entries to save created thread
	int	volatile		    nRunningThreads;	//the num of running threads
	  


	RUN_THREAD_EVENT_HANDLER pfnEventHandler;	//handler to process thread event
	pthread_mutex_t			hSyncLock;			//lock to protect the entry
	int						nLastEmptyEntry;	//the last release entry idx
	HANDLE					hManagerThread;		//thread id of the manager
};
typedef struct _RUN_THREAD_MANAGER	RUN_THREAD_MANAGER;

// dwThreadEvent enumerate of RUN_THREAD_EVENT_HANDLER:
enum _THREAD_EVENT_ENUM
{
	THREAD_EVENT_HEARTBEAT			  =	1,// The heartbeat event from thread
	THREAD_EVENT_NO_RESPONSE		  = 2,// the thread is no response event.
	THREAD_EVENT_MANAGER_HAS_STARTED  = 3,
//	THREAD_EVENT_IS_STOPPED	          =	4,// the thread is stooped.
	THREAD_EVENT_CANNOT_BE_STOPPED	  = 5,// the thread can NOT be stooped.
	THREAD_EVENT_MANAGER_HAS_STOPPED  =	6
};
struct _RUN_THREAD_ENTRY	//	The thread info
{				
	DWORD		dwThreadId;		// hiword is a magic word, 
								// low word is the index in thread manager

	char		szThreadName [LEN_RUN_THREAD_NAME];

	pthread_t	hSystemThread;	//	The ID of phread in Linux OS

	HANDLE	hMsgQueue;			//	the msg queue of the thread
	DWORD 	volatile dwThreadHeartbeat;	//	current thread heartbeat count

	int	volatile nStatus;			// The running status.
};

typedef struct _RUN_THREAD_ENTRY	RUN_THREAD_ENTRY;
struct _RUN_THREAD_START_ARG
{
	HANDLE				hThread;		// thread handle

	RUN_THREAD_START_PROC pfnThreadProc;// start proc
	void				*pThreadArg;	// start arg

	DWORD				*pdwExitCode;	// exit code ptr.

	pthread_mutex_t		hSyncLock;		// sync lock for creating thread
};
typedef struct _RUN_THREAD_START_ARG	RUN_THREAD_START_ARG;
struct _RUN_THREAD_MSG		//	The msg of thread
{				
	DWORD	dwMsg;		//	the msg type
	DWORD	dwParam1;	//	param1 of the msg
	DWORD	dwParam2;	//	param2 of the msg
	HANDLE	hSender;	//	the thread id of the sender
};

typedef struct _RUN_THREAD_MSG	RUN_THREAD_MSG;
typedef DWORD (*RUN_THREAD_EVENT_HANDLER)
(				
	DWORD	dwThreadEvent,		//	the thread event. below.
	HANDLE	hThread,			//	The thread id.
	const char	*pThreadName	//  the thread name.
);