#ifndef __FLASHLOG_H__
#define __FLASHLOG_H__


#define	FLAH_LOG_MAX_SIZE 	(1024*1024*1)

//void Flash_Log(const char *szTaskName,const int iLogLevel,
//			const char *pszFormat, ...);
//enum emLogLevel
//{
//	APP_LOG_INFO=0,
//	APP_LOG_WARNING,
//	APP_LOG_ERROR	
//}

#endif