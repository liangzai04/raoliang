 /*==========================================================================*
 *    Copyright(c) 2017-2027, ECJTU Co., Ltd.
 *                     ALL RIGHTS RESERVED
 *
 *  PRODUCT  : ACU(Advanced Controller Unit)
 *
 *  FILENAME : main.c
 *  CREATOR  : LiangRao (Lemon)         DATE: 2017-01-02 14:55
 *  VERSION  : V1.00
 *  PURPOSE  : write flash log
 *
 *
 *  HISTORY  :
 *
 *==========================================================================*/

#include"public.h"
#include "flashlog.h"

static pthread_mutex_t	hWriteLogLock;
/*��������
�������⣺����A B C  �����ͷ�˳��ҲӦ���� A B C*/
#define LOCK_FLASH_LOG_INIT()		  pthread_mutex_init(&hWriteLogLock, NULL)
#define LOCK_FLASH_LOG_SYNC()       pthread_mutex_lock(&hWriteLogLock)
#define UNLOCK_FLASH_LOG_SYNC()     pthread_mutex_unlock(&hWriteLogLock)
#define DESTROY_FLASH_LOG_SYNC()    pthread_mutex_destroy(&hWriteLogLock)

#define LOG_HEAD_INFO	"APP Log Format : [LogType#Time#Taskname#TaskID#LogMessage#]"

static BOOL Flash_LogFileBackUp()
{
	char szBackCmd_arr[32];
	sprintf(szBackCmd_arr,"mv %s %s",FILE_LOG_PATH,FILE_LOG_BACKUP);
	system(szBackCmd_arr);
}
static BOOL Flash_LogFileCreate()
{
	FILE *fp=fopen(FILE_LOG_PATH,"rb+");
	if(NULL == fp)
	{
		return FALSE;	
	}
	fprintf( fp, "%s\n", LOG_HEAD_INFO );
	fclose(fp);
	LOCK_FLASH_LOG_INIT();
	return TRUE;
}
void Flash_Log(const char *szTaskName,const int iLogLevel,
			const char *pszFormat, ...)
{
#define MAX_LOGINFO_LEN 256
	static	bFileLogInited =FALSE;
	int		iLogSize		  =0;
	char	*pszInfoLevel;	 //error level info
	char	 szTime_arr[32];	 // time format 
	char	szLogInfo[MAX_LOGINFO_LEN];
	FILE	*fp		= NULL;
	char	*arglist  =NULL;
	unsigned char   nLen = 0;

	//1. create log file		�ڵ���ʱInit�ô�������Ҫ�ڳ����ʼ��ʱȥר�ų�ʼ��log�ӿ�
	if(! bFileLogInited)
	{
		bFileLogInited=Flash_LogFileCreate();
	}

	//2.lock file and open 
	LOCK_FLASH_LOG_SYNC();
	/*
	go to ���Ӧ�ã�Ϊ���Ż�����ṹ����ʡ���룬
	������ʹ���ˣ�goto��䣬����־�ļ����󱸷�
	��־�ļ� Ȼ�����´��ļ�������һ��ѭ����
	Risk��  �����ѭ���� ��ɳ���ṹ����
		
	*/
_OpenAgain:
	fp = fopen( FILE_LOG_PATH, "a+" );
	if( fp == NULL )
	{
		fprintf( stderr, "Open log file %s fail.\n", FILE_LOG_PATH );
		UNLOCK_APP_LOG_SYNC();
		return;
	}
	fseek(fp,0,SEEK_END);
	iLogSize = ftell(fp);

	//3. logsize> Max ,backup file and recreate log file
	if(iLogSize >= FLAH_LOG_MAX_SIZE)
	{
		//log full, close fp
		fflush( fp );
		fclose( fp );

		Flash_LogFileBackUp();
		bFileLogInited=Flash_LogFileCreate();
		goto _OpenAgain;
	}

	//4.log level info 
	switch(iLogLevel)
	{
	case APP_LOG_INFO:
		pszInfoLevel = "INFO";
		break;
	case APP_LOG_WARNING:
		pszInfoLevel = "WARN";
		break;
	case APP_LOG_ERROR:
		pszInfoLevel = "ERR ";
		break;
	default:
		pszInfoLevel = "NOR ";	// undefined
		break;	
	}

	//5. time stamp format
	TimeToString(time(NULL), TIME_CHN_FMT, sizeof(szTime_arr),szTime_arr);
	

	//6.variable-length	 arguments
	va_start(arglist, pszFormat);  //     arglist poiner to the first parameter
	nLen = vsnprintf(szLogInfo, sizeof(szLogInfo), pszFormat, arglist);
	va_end(arglist);	//arglist	=NULL

       // discard the end LF "\n"
	if(szLogInfo[nLen-1] == '\n')	
	{
		szLogInfo[nLen-1] = 0; 
	}

	//7. full log information
	fprintf( fp, "[%04s#%s#%-16s#%d: %s]\n", 
			pszInfoLevel,
			szTime_arr,		// lose the centry of year. from yyyy to yy.
			szTaskName,
			(unsigned int)RunThread_GetId(NULL),   
			szLogInfo);

	//lose fp
	fflush( fp );
	fclose( fp );
	UNLOCK_FLASH_LOG_SYNC();
	return ;
}