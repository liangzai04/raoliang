#ifndef __USER_ERROR_H__
#define __USER_ERROR_H__



#define ERR_OK 1
#define ERR_FAIL0