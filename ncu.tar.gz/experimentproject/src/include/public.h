
#ifndef __PUBLIC_H__
#define __PUBLIC_H__
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>	 //for BOOL
 #include<fcntl.h>	// for file operation
#include<time.h>
#include <pthread.h>
//include all public head file ,so that you can call any function you want 
#include "pub_handler.h"
#include "pub_time.h"
#include "pub_flashlog.h"
#include "debug.h"
#include "basetype.h"
#include "device_node.h"

#define	_APP_DEBUG
#define _APP_TEST


#endif 