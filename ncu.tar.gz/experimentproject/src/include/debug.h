#ifndef __DEBUG_H__
#define __DEBUG_H__



#define	 _DEBUG
#ifdef _DEBUG
#define TRACE   printf
// trace with function and line number
#define TRACEX	printf("[%s:%d] -- ", __FUNCTION__, __LINE__), printf
#else
#define TRACE   1 ? (void)0 : (void)printf
#define TRACEX	1 ? ( void)0 : (void)printf
#endif



#endif
