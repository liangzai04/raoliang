#ifndef __PUBFLASHLOG_H__
#define __PUBFLASHLOG_H__

enum emLogLevel
{
	APP_LOG_INFO=0,
	APP_LOG_WARNING,
	APP_LOG_ERROR	
};
void Flash_Log(const char *szTaskName,const int iLogLevel,
			const char *pszFormat, ...);


#endif