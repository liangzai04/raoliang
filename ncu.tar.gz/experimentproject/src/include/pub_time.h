#ifndef __PUB_TIME_H__
#define __PUB_TIME_H__
#define TIME_CHN_FMT		"%Y-%m-%d %H:%M:%S"	// YYYYMMDD hhmmss
#define TIME_COMPACT_FMT	"%y%m%d %H%M%S"		// YYMMDDhhmmss
#define TIME_HISDATA_FMT		"%Y/%m/%d %H:%M:%S"	// YYYYMMDD hhmmss
void Time_GetCharactersFormat( char * psz_TimeArr);










#endif 